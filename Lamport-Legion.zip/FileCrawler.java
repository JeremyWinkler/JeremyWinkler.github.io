import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;

public class FileCrawler {
	
	final static String SRC_ROOT = "C:/Users/polj9/Desktop/intellij src/";

	public static void recurseDir(File f) {
		for (String item : f.list()) {
			
			File currItem = new File(f.getAbsolutePath() + File.separator + item);
			
			if (currItem.isDirectory())
				recurseDir(currItem);
			else
				System.out.println(currItem.getAbsolutePath());		
			
		}
		
	}
	
	public static void main(String[] args) throws FileNotFoundException {
		
        PrintStream out = new PrintStream(new File(SRC_ROOT + "src_filelist_raw.txt"));
        System.setOut(out);
        
        File root = new File(SRC_ROOT);
        
        recurseDir(root);
        
	}

}
