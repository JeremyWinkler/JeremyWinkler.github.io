import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ImportScanner {
	
	private final static String A3_FOLDER = "C:/Users/polj9/Desktop/4314 A3/";
	private final static String SRC_FOLDER = "C:/Users/polj9/Desktop/intellij src/";

    public static ArrayList<String> readFile(String f, boolean limited) throws IOException {
    	// if limited is true, read the first n lines specified by the variable 'limit'
    	File toRead = new File(f);
        FileReader fr = new FileReader(toRead);
        BufferedReader br = new BufferedReader(fr);
        String s;
        ArrayList<String> output = new ArrayList<String>();
        int i = 0, limit = 100;

        while ((s = br.readLine()) != null && i < limit){
            output.add(s);
            
            if (limited)
            	i++;
        }

        br.close();
        fr.close();
        return output;
    }
	
	public static void main(String[] args) throws IOException {
		
        PrintStream out = new PrintStream(new File(A3_FOLDER + "method2_deps.txt"));
        System.setOut(out);
		
        // provide file that lists all java files in IntelliJ
		ArrayList<String> instances = readFile(A3_FOLDER + "src_filelist_java.txt", false);
 
        // store key-value pairings of package path to complete path
		HashMap<String, String> db = new HashMap<String, String>(63289);		
		for (String instance : instances) {

            String pattern = "^(.*/src/|src/|.*-src/|.*/gen/|.*Src/|.*/test/|"
            		+ ".*pluginCore/|.*pluginJava/|.*pluginMinor/|.*-support/|"
            		+ ".*/source/|.*/concurrency/)(.*)";
            Pattern r = Pattern.compile(pattern);
            Matcher m = r.matcher(instance);

            if (m.find())
            	// key is package path
            	// value is the whole path from the root folder
                db.put(m.group(2), m.group(0));
            else {
            	// when source code path is not one of known patterns,
            	//   just take the filename as key
            	String[] path = instance.split("/");
            	String key = path[path.length - 1]; // take last token
            	db.put(key, instance);
            }       
			
		}
				
		// read the source file
        for (String instance : instances) {
        	
        	ArrayList<String> lines = readFile(SRC_FOLDER + instance, true);
            String pattern = "^(\\s*import)\\s+(static\\s+)?(.*)\\s*;\\s*([/]{2})*.*";
            Pattern r = Pattern.compile(pattern);
            Matcher m;
        	
        	// scan for imports in the current file
        	for (String line : lines) {
 
                m = r.matcher(line);
                
                if (m.find()) {
                	String imp = m.group(3).trim().replaceAll("\\.", "/") + ".java"; // the imported class
                	System.out.print(instance + " ");
                	
        			if (db.keySet().contains(imp))
        				System.out.println(db.get(imp));
        			else
        				System.out.println(imp);
                	
                }
                
        	}
	
        }	
		
	}

}
